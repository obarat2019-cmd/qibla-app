import flet as ft
from pages.qibla_page import show_qibla_page

def show_prayer_page(page: ft.Page, go_home):
    page.clean()
    page.add(
        ft.Column([
            ft.Row([
                ft.IconButton(icon=ft.Icons.ARROW_BACK, on_click=lambda e: go_home()),
                ft.Text("الصلاة", size=24, weight=ft.FontWeight.BOLD, color=ft.Colors.GREEN_900),
            ], alignment=ft.MainAxisAlignment.START),
            ft.Divider(height=20, color=ft.Colors.TRANSPARENT),
            ft.FilledButton(content=ft.Text("مواقيت الصلاة")),
            ft.FilledButton(content=ft.Text("تعليم الصلاة")),
            ft.FilledButton(content=ft.Text("أذكار بعد الصلاة")),
            ft.FilledButton(
                content=ft.Text("قبلة"),
                on_click=lambda e: show_qibla_page(page, go_home)
            ),
        ], spacing=10, horizontal_alignment=ft.CrossAxisAlignment.CENTER)
    )
    page.update()