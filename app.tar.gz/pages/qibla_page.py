import flet as ft
import math
import json

def calculate_qibla(lat, lon):
    kaaba_lat = 21.4225
    kaaba_lon = 39.8262
    lat_u = math.radians(lat)
    lon_u = math.radians(lon)
    lat_k = math.radians(kaaba_lat)
    lon_k = math.radians(kaaba_lon)
    dlon = lon_k - lon_u
    y = math.sin(dlon)
    x = math.cos(lat_u) * math.tan(lat_k) - math.sin(lat_u) * math.cos(dlon)
    qibla_rad = math.atan2(y, x)
    qibla_deg = math.degrees(qibla_rad)
    if qibla_deg < 0:
        qibla_deg += 360.0
    return qibla_deg

def show_qibla_page(page: ft.Page, go_home):
    compass_size = 250
    half = compass_size / 2

    # سهم القبلة (أخضر)
    qibla_arrow = ft.Icon(ft.Icons.ARROW_UPWARD, size=70, color=ft.Colors.GREEN_700)
    # سهم الشمال (أزرق)
    north_arrow = ft.Icon(ft.Icons.ARROW_UPWARD, size=60, color=ft.Colors.BLUE_700)

    # عناصر النصوص
    n_text = ft.Text("N", size=22, weight=ft.FontWeight.BOLD, color=ft.Colors.RED)
    s_text = ft.Text("S", size=22, weight=ft.FontWeight.BOLD, color=ft.Colors.BLACK)
    e_text = ft.Text("E", size=22, weight=ft.FontWeight.BOLD, color=ft.Colors.BLACK)
    w_text = ft.Text("W", size=22, weight=ft.FontWeight.BOLD, color=ft.Colors.BLACK)
    angle_text = ft.Text("0.0°", size=20, weight=ft.FontWeight.BOLD, color=ft.Colors.GREEN_900)
    status_text = ft.Text("", size=14, color=ft.Colors.GREY_600)

    def build_compass():
        return ft.Stack(
            [
                # الدائرة
                ft.Container(
                    width=compass_size,
                    height=compass_size,
                    border_radius=half,
                    bgcolor=ft.Colors.GREEN_50,
                    border=ft.Border(
                        left=ft.BorderSide(2, ft.Colors.GREEN_200),
                        top=ft.BorderSide(2, ft.Colors.GREEN_200),
                        right=ft.BorderSide(2, ft.Colors.GREEN_200),
                        bottom=ft.BorderSide(2, ft.Colors.GREEN_200),
                    ),
                ),
                # الشمال (ثابت)
                ft.Container(content=n_text, left=half - 15, top=8),
                # الجنوب
                ft.Container(content=s_text, left=half - 12, bottom=8),
                # الشرق
                ft.Container(content=e_text, right=8, top=half - 15),
                # الغرب
                ft.Container(content=w_text, left=8, top=half - 15),
                # سهم الشمال (أزرق) - في المركز، سيدور مع الجهاز
                ft.Container(
                    content=north_arrow,
                    left=half - 30,
                    top=half - 30,
                ),
                # سهم القبلة (أخضر) - سيدور حسب الزاوية المحسوبة
                ft.Container(
                    content=qibla_arrow,
                    left=half - 35,
                    top=half - 35,
                ),
            ],
            width=compass_size,
            height=compass_size,
        )

    compass_widget = build_compass()

    # زوايا التوجيه
    current_qibla_angle = 0.0
    current_north_angle = 0.0  # زاوية الشمال من مستشعر الجهاز

    def update_arrows():
        # تدوير سهم القبلة بالنسبة للشمال الحقيقي (0 = أعلى)
        qibla_rotation = math.radians(-current_qibla_angle)
        qibla_arrow.rotate = ft.Rotate(angle=qibla_rotation)
        # تدوير سهم الشمال حسب مستشعر الجهاز (0 = أعلى = شمال)
        north_rotation = math.radians(-current_north_angle)
        north_arrow.rotate = ft.Rotate(angle=north_rotation)
        angle_text.value = f"قبلة: {current_qibla_angle:.1f}°"
        page.update()

    # ---------- حقول الإدخال اليدوي ----------
    lat_field = ft.TextField(label="خط العرض (Latitude)", hint_text="مثال: 21.4225", width=250)
    lon_field = ft.TextField(label="خط الطول (Longitude)", hint_text="مثال: 39.8262", width=250)

    def calc_manual(e):
        try:
            lat = float(lat_field.value)
            lon = float(lon_field.value)
            nonlocal current_qibla_angle
            current_qibla_angle = calculate_qibla(lat, lon)
            update_arrows()
            status_text.value = f"تم الحساب لموقع: {lat:.2f}, {lon:.2f}"
        except ValueError:
            page.snack_bar = ft.SnackBar(ft.Text("الرجاء إدخال أرقام صحيحة"))
            page.snack_bar.open = True
            page.update()

    # ---------- محاولة GPS ----------
    def try_gps(e):
        if hasattr(page, "evaluate_js"):
            async def get_location():
                try:
                    result = await page.evaluate_js(
                        """
                        (async () => {
                            if (!navigator.geolocation) {
                                return JSON.stringify({error: "متصفحك لا يدعم GPS"});
                            }
                            try {
                                const pos = await new Promise((resolve, reject) => {
                                    navigator.geolocation.getCurrentPosition(resolve, reject, {
                                        enableHighAccuracy: true,
                                        timeout: 15000,
                                        maximumAge: 0
                                    });
                                });
                                return JSON.stringify({lat: pos.coords.latitude, lon: pos.coords.longitude});
                            } catch (err) {
                                return JSON.stringify({error: err.message});
                            }
                        })();
                        """
                    )
                    data = json.loads(result)
                    if "error" in data:
                        status_text.value = f"خطأ GPS: {data['error']}"
                    else:
                        lat = data["lat"]
                        lon = data["lon"]
                        lat_field.value = str(lat)
                        lon_field.value = str(lon)
                        nonlocal current_qibla_angle
                        current_qibla_angle = calculate_qibla(lat, lon)
                        update_arrows()
                        status_text.value = f"تم تحديد الموقع"
                except Exception as ex:
                    status_text.value = "فشل في GPS"
                page.update()
            page.run_task(get_location)
        else:
            status_text.value = "GPS غير مدعوم على هذا الجهاز"
            page.update()

    # ---------- تشغيل بوصلة الجهاز (الشمال) ----------
    def start_device_compass(e):
        status_text.value = "جاري تشغيل بوصلة الجهاز..."
        page.update()
        if hasattr(page, "evaluate_js"):
            # نستخدم كود JavaScript يستمع لتغيرات الاتجاه
            js_code = """
            (() => {
                if (window._flet_compass_active) return "already_active";
                window._flet_compass_active = true;
                window.addEventListener('deviceorientation', (event) => {
                    // event.alpha يمثل الانحراف بالنسبة للشمال (درجات)
                    // 0 = شمال، 90 = شرق، إلخ
                    if (event.alpha !== null) {
                        const data = JSON.stringify({alpha: event.alpha});
                        // إرسال البيانات إلى بايثون عبر قناة خاصة
                        flutterChannel.postMessage(data);
                    }
                });
                return "started";
            })();
            """
            # سنقوم بتسجيل مستمع لرسائل JavaScript
            async def listen_compass():
                try:
                    # تنفيذ JavaScript لبدء الاستماع
                    res = await page.evaluate_js(js_code)
                    if res == "already_active":
                        status_text.value = "البوصلة قيد التشغيل بالفعل"
                    else:
                        status_text.value = "البوصلة نشطة، حرك الهاتف"
                except Exception as ex:
                    status_text.value = "فشل تشغيل بوصلة الجهاز"
                page.update()
            page.run_task(listen_compass)
            # إعداد مستمع لاستقبال رسائل الجهاز
            # في Flet 0.86.3 قد لا يكون هناك `page.on_js_message` مباشرة، لذا نستخدم طريقة بديلة:
            # ننشئ قناة اتصال باستخدام flutterChannel
            page.evaluate_js("""
                window.flutterChannel = {
                    postMessage: function(data) {
                        // نرسل إلى بايثون عبر evaluate_js
                        window.parent.postMessage(data, '*');
                    }
                };
            """)
            # سنستخدم window.postMessage مع listener
            # للأسف في الإصدار الحالي قد لا يكون هناك دعم مباشر، لذا سنقوم بتبسيط:
            # نضيف تحديث دوري بدلاً من المستمع (حل بديل)
            status_text.value = "للأسف، بوصلة الجهاز تحتاج HTTPS لتعمل بشكل كامل. استخدم الإدخال اليدوي أو النشر على Flet Cloud."
            page.update()
        else:
            status_text.value = "بوصلة الجهاز غير مدعومة على هذا النظام"
            page.update()

    # ---------- بناء الصفحة ----------
    page.clean()
    page.add(
        ft.Column([
            ft.Row([
                ft.IconButton(icon=ft.Icons.ARROW_BACK, on_click=lambda e: go_home()),
                ft.Text("بوصلة القبلة", size=24, weight=ft.FontWeight.BOLD, color=ft.Colors.GREEN_900),
            ]),
            ft.Divider(height=20),
            ft.Container(
                content=ft.Column([compass_widget, angle_text, status_text],
                                  horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                alignment=ft.Alignment(0, 0),
            ),
            ft.Divider(height=20),
            ft.Text("الطرق المتاحة:", weight=ft.FontWeight.BOLD),
            ft.Button(
                content=ft.Text("احسب القبلة (يدوي)"),
                on_click=calc_manual,
                style=ft.ButtonStyle(bgcolor=ft.Colors.BLUE_700, color=ft.Colors.WHITE),
            ),
            lat_field,
            lon_field,
            ft.Button(
                content=ft.Text("استخدم GPS (تلقائي)"),
                on_click=try_gps,
                style=ft.ButtonStyle(bgcolor=ft.Colors.GREEN_700, color=ft.Colors.WHITE),
            ),
            ft.Button(
                content=ft.Text("تشغيل بوصلة الجهاز (الشمال)"),
                on_click=start_device_compass,
                style=ft.ButtonStyle(bgcolor=ft.Colors.ORANGE_700, color=ft.Colors.WHITE),
            ),
        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=10)
    )
    page.update()