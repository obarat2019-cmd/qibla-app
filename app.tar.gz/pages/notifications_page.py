import flet as ft

def show_notifications_page(page: ft.Page, go_home):
    page.clean()
    page.add(
        ft.Column([
            ft.Row([
                ft.IconButton(icon=ft.Icons.ARROW_BACK, on_click=lambda e: go_home()),
                ft.Text("إشعارات", size=24, weight=ft.FontWeight.BOLD, color=ft.Colors.GREEN_900),
            ], alignment=ft.MainAxisAlignment.START),
            ft.Divider(height=20, color=ft.Colors.TRANSPARENT),
            ft.Text("لا توجد إشعارات حالياً", color=ft.Colors.GREY_600),
        ], spacing=10, horizontal_alignment=ft.CrossAxisAlignment.CENTER)
    )
    page.update()