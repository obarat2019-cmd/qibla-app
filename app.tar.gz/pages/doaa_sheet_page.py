import flet as ft

def show_doaa_sheet_page(page: ft.Page, go_home, show_dua_content):
    items = [
        ("أدعية الصباح والمساء", "أدعية_الصباح_والمساء.txt"),
        ("أدعية السفر", "أدعية_السفر.txt"),
        ("أدعية المرض", "أدعية_المرض.txt"),
        ("أدعية الرزق", "أدعية_الرزق.txt"),
    ]

    def open_dua(e):
        name = e.control.data["name"]
        file_name = e.control.data["file"]
        show_dua_content(name, file_name)

    page.clean()
    page.add(
        ft.Column([
            ft.Row([
                ft.IconButton(icon=ft.Icons.ARROW_BACK, on_click=lambda e: go_home()),
                ft.Text("صحيفة الأدعية", size=24, weight=ft.FontWeight.BOLD, color=ft.Colors.GREEN_900),
            ]),
            ft.Divider(height=20, color=ft.Colors.TRANSPARENT),
            *[
                ft.FilledButton(
                    content=ft.Text(name),
                    data={"name": name, "file": file},
                    on_click=open_dua
                ) for name, file in items
            ],
        ], spacing=10, horizontal_alignment=ft.CrossAxisAlignment.CENTER)
    )
    page.update()