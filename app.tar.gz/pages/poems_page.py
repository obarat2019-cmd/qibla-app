import flet as ft

def show_poems_page(page: ft.Page, go_home):
    page.clean()
    page.add(
        ft.Column([
            ft.Row([
                ft.IconButton(icon=ft.Icons.ARROW_BACK, on_click=lambda e: go_home()),
                ft.Text("قصائد", size=24, weight=ft.FontWeight.BOLD, color=ft.Colors.GREEN_900),
            ], alignment=ft.MainAxisAlignment.START),
            ft.Divider(height=20, color=ft.Colors.TRANSPARENT),
            ft.FilledButton("قصائد دينية", on_click=lambda e: print("دينية")),
            ft.FilledButton("مدائح نبوية", on_click=lambda e: print("مدائح")),
            ft.FilledButton("قصائد مختارة", on_click=lambda e: print("مختارة")),
        ], spacing=10, horizontal_alignment=ft.CrossAxisAlignment.CENTER)
    )
    page.update()