import flet as ft

def show_ramadan_page(page: ft.Page, go_home, show_dua_content):
    ramadan_items = [
        ("أدعية رمضان", "أدعية_رمضان.docx"),
        ("صلوات التراويح", "صلوات_التراويح.txt"),
        ("زكاة الفطر", "زكاة_الفطر.txt"),
        ("فضل رمضان", "فضل_رمضان.txt"),
        ("ضل رمضان", "ضل_رمضان.txt"),
    ]

    def open_dua(e):
        name = e.control.data["name"]
        file_name = e.control.data["file"]
        show_dua_content(name, file_name)

    page.clean()
    page.add(
        ft.Column([
            ft.Row([
                ft.IconButton(icon=ft.Icons.ARROW_BACK, on_click=lambda e: go_home()),
                ft.Text("رمضان", size=24, weight=ft.FontWeight.BOLD, color=ft.Colors.GREEN_900),
            ]),
            ft.Divider(height=20, color=ft.Colors.TRANSPARENT),
            *[
                ft.FilledButton(
                    content=ft.Text(name),
                    data={"name": name, "file": file},
                    on_click=open_dua
                ) for name, file in ramadan_items
            ],
        ], spacing=10, horizontal_alignment=ft.CrossAxisAlignment.CENTER)
    )
    page.update()