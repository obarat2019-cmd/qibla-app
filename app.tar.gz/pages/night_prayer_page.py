import flet as ft

def show_night_prayer_page(page: ft.Page, go_home):
    page.clean()
    page.add(
        ft.Column([
            ft.Row([
                ft.IconButton(icon=ft.Icons.ARROW_BACK, on_click=lambda e: go_home()),
                ft.Text("صلاة الليل", size=24, weight=ft.FontWeight.BOLD, color=ft.Colors.GREEN_900),
            ], alignment=ft.MainAxisAlignment.START),
            ft.Divider(height=20, color=ft.Colors.TRANSPARENT),
            ft.FilledButton("كيفية صلاة الليل", on_click=lambda e: print("كيفية")),
            ft.FilledButton("أدعية صلاة الليل", on_click=lambda e: print("أدعية")),
            ft.FilledButton("عدد الركعات", on_click=lambda e: print("ركعات")),
        ], spacing=10, horizontal_alignment=ft.CrossAxisAlignment.CENTER)
    )
    page.update()