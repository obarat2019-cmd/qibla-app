import flet as ft
import os
import docx
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH

from pages.prayer_page import show_prayer_page
from pages.ramadan_page import show_ramadan_page
from pages.night_prayer_page import show_night_prayer_page
from pages.poems_page import show_poems_page
from pages.notifications_page import show_notifications_page
from pages.doaa_sheet_page import show_doaa_sheet_page
from pages.quran_page import show_quran_page

favorite_duas = []

def docx_to_paragraphs(file_path):
    doc = docx.Document(file_path)
    paragraphs_data = []
    
    for para in doc.paragraphs:
        full_text = para.text
        if not full_text.strip():
            paragraphs_data.append({
                "text": "",
                "color": None,
                "size": None,
                "bold": False,
                "italic": False,
                "alignment": ft.TextAlign.RIGHT
            })
            continue
        
        color_str = None
        size_pt = 12
        bold = False
        italic = False
        alignment = ft.TextAlign.RIGHT
        
        if para.alignment == WD_ALIGN_PARAGRAPH.CENTER:
            alignment = ft.TextAlign.CENTER
        elif para.alignment == WD_ALIGN_PARAGRAPH.LEFT:
            alignment = ft.TextAlign.LEFT
        elif para.alignment == WD_ALIGN_PARAGRAPH.RIGHT:
            alignment = ft.TextAlign.RIGHT
        elif para.alignment == WD_ALIGN_PARAGRAPH.JUSTIFY:
            alignment = ft.TextAlign.JUSTIFY
        
        if para.runs:
            run = para.runs[0]
            font = run.font
            
            size = font.size
            if size is None and para.style and para.style.font.size:
                size = para.style.font.size
            size_pt = size.pt if size else 12
            
            if font.color and font.color.rgb:
                color_str = f"#{font.color.rgb}"
            elif para.style and para.style.font.color and para.style.font.color.rgb:
                color_str = f"#{para.style.font.color.rgb}"
            
            bold = font.bold if font.bold is not None else (
                para.style.font.bold if para.style and para.style.font.bold is not None else False
            )
            italic = font.italic if font.italic is not None else (
                para.style.font.italic if para.style and para.style.font.italic is not None else False
            )
        else:
            if para.style:
                sf = para.style.font
                if sf.size:
                    size_pt = sf.size.pt
                if sf.color and sf.color.rgb:
                    color_str = f"#{sf.color.rgb}"
                bold = sf.bold if sf.bold is not None else False
                italic = sf.italic if sf.italic is not None else False
        
        lines = full_text.splitlines()
        for line in lines:
            paragraphs_data.append({
                "text": line.strip(),
                "color": color_str,
                "size": size_pt,
                "bold": bold,
                "italic": italic,
                "alignment": alignment
            })
    
    return paragraphs_data

def get_dua_content(file_name):
    base_dir = os.path.dirname(__file__)
    file_path = os.path.join(base_dir, "assets", "prayers", file_name)
    if not os.path.exists(file_path):
        return [{
            "text": "الملف غير موجود.",
            "color": None,
            "size": 16,
            "bold": False,
            "italic": False,
            "alignment": ft.TextAlign.RIGHT
        }]

    if file_name.lower().endswith('.docx'):
        try:
            return docx_to_paragraphs(file_path)
        except Exception as e:
            return [{
                "text": f"خطأ: {e}",
                "color": None,
                "size": 16,
                "bold": False,
                "italic": False,
                "alignment": ft.TextAlign.RIGHT
            }]
    else:
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                lines = [line.strip() for line in f.read().splitlines() if line.strip()]
            return [{
                "text": line,
                "color": None,
                "size": 16,
                "bold": False,
                "italic": False,
                "alignment": ft.TextAlign.RIGHT
            } for line in lines]
        except Exception as e:
            return [{
                "text": f"خطأ: {e}",
                "color": None,
                "size": 16,
                "bold": False,
                "italic": False,
                "alignment": ft.TextAlign.RIGHT
            }]

async def main(page: ft.Page):
    global favorite_duas

    page.title = "تسجيل الدخول"
    page.window.width = 390
    page.window.height = 844
    page.window.resizable = False
    if not page.web:
        await page.window.center()
    page.bgcolor = ft.Colors.GREEN_50

    def go_home():
        show_home_page()

    def toggle_favorite(file_name, title):
        global favorite_duas
        if file_name in favorite_duas:
            favorite_duas.remove(file_name)
            page.snack_bar = ft.SnackBar(ft.Text(f"تم إزالة '{title}' من المفضلة"))
        else:
            favorite_duas.append(file_name)
            page.snack_bar = ft.SnackBar(ft.Text(f"تم إضافة '{title}' إلى المفضلة"))
        page.snack_bar.open = True
        show_dua_content(title, file_name)

    def show_dua_content(title, file_name):
        paragraphs_data = get_dua_content(file_name)
        is_fav = file_name in favorite_duas

        # عرض الحاوية المتاح (بعد خصم الهوامش)
        available_width = page.window.width - 60  # 30 padding من كل جانب تقريبًا

        def fit_style(pdata):
            """ينشئ TextStyle مع تصغير الحجم ليناسب العرض بدون لف"""
            original_size = pdata["size"] if pdata["size"] else 16
            text = pdata["text"]
            if not text:
                return ft.TextStyle(
                    color=pdata["color"] if pdata["color"] else ft.Colors.BLACK,
                    size=original_size,
                    weight=ft.FontWeight.BOLD if pdata["bold"] else ft.FontWeight.NORMAL,
                    italic=pdata["italic"]
                )
            # تقدير عرض النص: كل حرف ≈ 0.55 من حجم الخط (بالبكسل)
            estimated_width = len(text) * original_size * 0.55
            if estimated_width <= available_width:
                fitted_size = original_size
            else:
                fitted_size = available_width / (len(text) * 0.55)
                fitted_size = max(8, fitted_size)  # لا يقل عن 8
            return ft.TextStyle(
                color=pdata["color"] if pdata["color"] else ft.Colors.BLACK,
                size=fitted_size,
                weight=ft.FontWeight.BOLD if pdata["bold"] else ft.FontWeight.NORMAL,
                italic=pdata["italic"]
            )

        text_widgets = []
        for pdata in paragraphs_data:
            style = fit_style(pdata)
            # no_wrap=True يمنع الالتفاف، ويُبقي السطر في سطر واحد
            text_widgets.append(
                ft.Container(
                    content=ft.Text(
                        pdata["text"],
                        style=style,
                        text_align=pdata["alignment"],
                        rtl=True,
                        no_wrap=True,
                        overflow=ft.TextOverflow.ELLIPSIS,  # إن تجاوز بعد التصغير
                    ),
                    width=available_width,
                )
            )

        fav_button = ft.Button(
            content=ft.Text("إزالة من المفضلة" if is_fav else "جعله الدعاء المفضل",
                            color=ft.Colors.WHITE),
            on_click=lambda e: toggle_favorite(file_name, title),
            style=ft.ButtonStyle(
                bgcolor=ft.Colors.RED_700 if is_fav else ft.Colors.GREEN_700,
                color=ft.Colors.WHITE,
                padding=ft.Padding(left=20, top=10, right=20, bottom=10),
            )
        )

        page.clean()
        page.add(
            ft.Column([
                ft.Row([
                    ft.IconButton(icon=ft.Icons.ARROW_BACK, on_click=lambda e: go_home()),
                    ft.Text(title, size=24, weight=ft.FontWeight.BOLD,
                            color=ft.Colors.GREEN_900),
                ]),
                ft.Divider(height=10, color=ft.Colors.TRANSPARENT),
                ft.ListView(
                    controls=text_widgets,
                    spacing=10,
                    padding=10,
                    expand=True,
                ),
                ft.Divider(height=10, color=ft.Colors.TRANSPARENT),
                fav_button,
            ], spacing=5, horizontal_alignment=ft.CrossAxisAlignment.CENTER,
               expand=True)
        )
        page.update()

    def show_favorite_prayers():
        if not favorite_duas:
            page.clean()
            page.add(
                ft.Column([
                    ft.Row([
                        ft.IconButton(icon=ft.Icons.ARROW_BACK, on_click=lambda e: go_home()),
                        ft.Text("أدعيتي", size=24, weight=ft.FontWeight.BOLD,
                                color=ft.Colors.GREEN_900),
                    ]),
                    ft.Divider(height=20, color=ft.Colors.TRANSPARENT),
                    ft.Text("لا توجد أدعية مفضلة بعد.", color=ft.Colors.GREY_600, size=14),
                    ft.Text("يمكنك إضافتها من الأقسام الأخرى.", color=ft.Colors.GREY_600, size=14),
                ], spacing=10, horizontal_alignment=ft.CrossAxisAlignment.CENTER)
            )
            page.update()
            return

        buttons_list = []
        for file_name in favorite_duas:
            display_name = os.path.splitext(file_name)[0]
            btn = ft.FilledButton(
                content=ft.Text(display_name),
                data=file_name,
                on_click=lambda e: show_dua_content(
                    os.path.splitext(e.control.data)[0],
                    e.control.data
                ),
                style=ft.ButtonStyle(
                    bgcolor=ft.Colors.GREEN_700,
                    color=ft.Colors.WHITE,
                ),
            )
            buttons_list.append(btn)

        page.clean()
        page.add(
            ft.Column([
                ft.Row([
                    ft.IconButton(icon=ft.Icons.ARROW_BACK, on_click=lambda e: go_home()),
                    ft.Text("أدعيتي", size=24, weight=ft.FontWeight.BOLD,
                            color=ft.Colors.GREEN_900),
                ]),
                ft.Divider(height=20, color=ft.Colors.TRANSPARENT),
                *buttons_list,
            ], spacing=10, horizontal_alignment=ft.CrossAxisAlignment.CENTER)
        )
        page.update()

    def login(e):
        its = its_field.value
        password = password_field.value
        if its == "52" and password == "52":
            page.clean()
            show_home_page()
        else:
            page.snack_bar = ft.SnackBar(ft.Text("رقم ITS أو كلمة المرور غير صحيحة!"))
            page.snack_bar.open = True
            page.update()

    def show_home_page():
        buttons = [
            ("أدعيتي", ft.Icons.BOOK),
            ("الصلاة", ft.Icons.MOSQUE),
            ("رمضان", ft.Icons.STAR),
            ("صلاة الليل", ft.Icons.NIGHTLIGHT),
            ("قصائد", ft.Icons.AUDIOTRACK),
            ("إشعارات", ft.Icons.NOTIFICATIONS),
            ("صحيفة الأدعية", ft.Icons.MENU_BOOK),
            ("القرآن", ft.Icons.LIBRARY_BOOKS),
        ]

        def button_clicked(e):
            button_name = e.control.data
            page.clean()
            if button_name == "أدعيتي":
                show_favorite_prayers()
            elif button_name == "الصلاة":
                show_prayer_page(page, go_home)
            elif button_name == "رمضان":
                show_ramadan_page(page, go_home, show_dua_content)
            elif button_name == "صلاة الليل":
                show_night_prayer_page(page, go_home)
            elif button_name == "قصائد":
                show_poems_page(page, go_home)
            elif button_name == "إشعارات":
                show_notifications_page(page, go_home)
            elif button_name == "صحيفة الأدعية":
                show_doaa_sheet_page(page, go_home, show_dua_content)
            elif button_name == "القرآن":
                show_quran_page(page, go_home, show_dua_content)

        rows = []
        for i in range(0, len(buttons), 2):
            row_buttons = []
            for label, icon in buttons[i:i+2]:
                btn = ft.FilledButton(
                    content=ft.Row([
                        ft.Icon(icon, size=28, color=ft.Colors.WHITE),
                        ft.Text(label, size=14, color=ft.Colors.WHITE),
                    ], alignment=ft.MainAxisAlignment.CENTER),
                    style=ft.ButtonStyle(
                        bgcolor=ft.Colors.GREEN_700,
                        padding=ft.Padding(left=15, top=20, right=15, bottom=20),
                    ),
                    data=label,
                    on_click=button_clicked,
                    expand=True,
                )
                row_buttons.append(btn)
            rows.append(ft.Row(row_buttons, alignment=ft.MainAxisAlignment.CENTER))

        buttons_grid = ft.Column(rows, spacing=15)

        page.clean()
        page.add(
            ft.Column([
                ft.Text("القائمة الرئيسية", size=28, weight=ft.FontWeight.BOLD,
                        color=ft.Colors.GREEN_900),
                ft.Text("اختر إحدى الخيارات", size=16, color=ft.Colors.GREEN_700),
                ft.Divider(height=30, color=ft.Colors.TRANSPARENT),
                buttons_grid,
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER)
        )
        page.update()

    # ------------------ واجهة تسجيل الدخول ------------------
    its_field = ft.TextField(
        label="أدخل رقم ال ITS",
        hint_text="مثال: ITS12345",
        width=300,
        text_align=ft.TextAlign.RIGHT,
        border_color=ft.Colors.GREEN_800,
        focused_border_color=ft.Colors.GREEN,
        value="52"
    )

    password_field = ft.TextField(
        label="أدخل كلمة المرور",
        hint_text="كلمة المرور",
        password=True,
        can_reveal_password=True,
        width=300,
        text_align=ft.TextAlign.RIGHT,
        border_color=ft.Colors.GREEN_800,
        focused_border_color=ft.Colors.GREEN,
        value="52"
    )

    remember_check = ft.Checkbox(
        label="تذكرني",
        value=False,
        active_color=ft.Colors.GREEN,
        check_color=ft.Colors.WHITE,
    )

    login_button = ft.FilledButton(
        content=ft.Text("تسجيل", size=18),
        on_click=login,
        style=ft.ButtonStyle(
            bgcolor=ft.Colors.GREEN_700,
            color=ft.Colors.WHITE,
            padding=ft.Padding(left=40, top=15, right=40, bottom=15),
        ),
        width=300,
    )

    login_view = ft.Container(
        content=ft.Column([
            ft.Text("مرحبًا بك!", size=32, weight=ft.FontWeight.BOLD,
                    color=ft.Colors.BLACK, text_align=ft.TextAlign.CENTER),
            ft.Text("الرجاء إدخال بياناتك لتسجيل الدخول", size=14,
                    color=ft.Colors.GREY_700, text_align=ft.TextAlign.CENTER),
            ft.Divider(height=20, color=ft.Colors.TRANSPARENT),
            its_field,
            password_field,
            ft.Divider(height=10, color=ft.Colors.TRANSPARENT),
            remember_check,
            ft.Divider(height=20, color=ft.Colors.TRANSPARENT),
            login_button,
        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
        padding=30,
        bgcolor=ft.Colors.WHITE,
        border_radius=15,
        shadow=ft.BoxShadow(
            blur_radius=10,
            color=ft.Colors.GREY_300,
            offset=ft.Offset(0, 5),
        ),
    )

    page.add(login_view)

ft.run(main)